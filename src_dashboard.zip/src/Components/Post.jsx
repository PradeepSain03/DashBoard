import React, { useEffect, useState } from "react";
import Order from "./Order";

export default function Post() {
    const [data, setData] = useState([])
    useEffect(() => {

        async function Data() {
            let res = await fetch("https://dashboard-880d8-default-rtdb.firebaseio.com/user.json");
            let data1 = await res.json();

            setData(data1.project)


        }
        Data();

    }, []);

    console.log(data)


    return (
        <>
            <div className="md:flex">
                <div className="p-4 col-span-2 w-[100%] md:w-[70%]">
                    <div className="rounded-[20px] border-[1px] ">
                        <div className="p-4">
                            <div>
                                <h1 className="font-bold text-xl">Project</h1>
                                <h1 className="font-bold text-gray "><i class="fa-solid fa-check text-blue-500"></i> 30 done this month</h1>
                            </div>
                            <i class="fa-solid fa-ellipsis-vertical float-right"></i>
                        </div>
                        <div className="grid grid-cols-4 text-gray mb-2 mt-5 p-4">
                            <h1>Companies</h1>
                            <h1>Member</h1>
                            <h1>Budget</h1>
                            <h1>Completion</h1>
                        </div>
                        <p className="border-[1px]"></p>

                        {data.map((item) => (

                            <div className="grid grid-cols-4 text-gray mb-2 mt-2 p-4">
                                <div className="grid gap-5">
                                    <img src={item.img} alt="" />
                                    <h1 className="font-bold">{item.companyName}</h1>
                                </div>

                                <img src={item.img} alt="" />
                                <h1 className="font-bold">{item.Budget}</h1>
                                <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                                    <div class="bg-blue-600 h-2.5 rounded-full" style={{ width: `${item.width}` }}></div>
                                </div>

                            </div>
                        ))}
                    </div>

                </div>
                <div className="md:w-[30%]  w-[100%]">   <Order /></div>
            </div>

        </>
    )
}